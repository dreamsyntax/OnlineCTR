SCUS 94426 only
ePSXe 2.0.5 only

Open the game
Pick Arcade 1P Easy
go to character selection
Open the hack

Server:
Press 1, hit enter
Enter port, hit enter

Client:
Press 2, hit enter
Enter IP, hit enter
Enter port, hit enter

Choose any character you want

While in Track Selection:
	If you want to play as Oxide, start holding F11, and keep holding F11 until race starts

	Let the host browse the tracks, the client should not touch anything (unless you want Oxide)
	The client will automatically copy the server, while server browses tracks, chooses laps, and starts race
	
	If you are the server, you can press F9, and then press Up (keyboard, controller, whichever).
	This will show you Lab Basement. If you want any Battle track, keep hitting the Up
	button to browse battle tracks. Pressing the Down button will go back to Crash Cove.
	This is very experimental, so the names of the battle maps dont show up. Still works though

	If you are the server, you can press F10, to select a random track. This will not
	include Battle Maps, only Race Maps

	When the race starts, you should only see 2 racers. If you see 8, something went wrong

Game Graphics:
	Terminology:
		LOD 1 means Level of Detail you would see in 1P Arcade
		LOD 2 meand Level of Detail you would see in 2P Arcade
		LOD 3 means Level of Detail you would see in 3P Vs
		LOD 4 means Level of Detail you would see in 4P Vs

	By default, graphics are LOD 1

	If you play as Oxide, LOD will drop to 2 on some tracks, or else the game crashes.
	This is a problem that happens on original PlayStation hardware.
	The following tracks, with Oxide, will play in LOD 2 graphics
		Mystery Caves
		Polar Pass
		Cortex Castle
		Hot Air Skyway
		N Gin Labs
		Oxide Station

	If the person you are playing online with, is using an unlocked character, then
	LOD is set to level 3, or else the game crashes. One day we hope to fix this,
	and allow the game to run in LOD 1 regardless of what the online player chooses.
	If an online player chooses these characters, LOD is set to 3:
		Ripper Roo
		Papu Papu
		Komodo Joe
		Pinstripe
		Oxide
		Penta Penguin
		Fake Crash
		N. Tropy

System stability with Oxide is not perfect. This mod makes CTR more stable
with Oxide than the original PlayStation hardware. However, some menus may
freeze while the oxide cheat is enabled	